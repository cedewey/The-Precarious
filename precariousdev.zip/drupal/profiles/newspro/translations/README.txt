// $Id: README.txt,v 1.1 2010/09/22 01:49:17 webchick Exp $

This directory should be used to place downloaded translations
for installing Drupal core.
