<ul class="post-list">
<?php 
foreach ($rows as $id => $row) {
print $row;
}
?>
</ul>