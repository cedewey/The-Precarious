<fieldset>
<input type="text" name="search_block_form" class="text" value="Search..." />
<input type="submit" class="submit" name="op" id="searchsubmit" value="<?php print t('Search'); ?>" />
</fieldset>
<?php print $search['hidden']; ?>