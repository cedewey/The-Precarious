<div class="tags">
<?php 
foreach ($rows as $id => $row) {
print $row;
}
?>
</div>